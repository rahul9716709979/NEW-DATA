TRUNCATE TABLE colleges RESTART IDENTITY;
INSERT INTO colleges (name) VALUES ('College 1');
INSERT INTO colleges (name) VALUES ('College 2');
INSERT INTO colleges (name) VALUES ('College 3');
